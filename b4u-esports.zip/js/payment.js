export async function initiatePayment() {
    try {
        const paymentData = {
            amount: 1.0,
            memo: "Purchase of in-game tokens",
            metadata: { orderId: `ORDER_${Date.now()}` }
        };
        const callbacks = {
            onReadyForServerApproval: async (paymentId) => {
                console.log('Payment ready for approval:', paymentId);
                const response = await fetch('/api/approve-payment', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ paymentId })
                });
                const result = await response.json();
                if (!result.success) {
                    console.error('Payment approval failed:', result.error);
                    alert('Payment approval failed. Please try again.');
                }
            },
            onReadyForServerCompletion: async (paymentId, txid) => {
                console.log('Payment completed:', paymentId, txid);
                const response = await fetch('/api/complete-payment', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ paymentId, txid })
                });
                const result = await response.json();
                if (result.success) {
                    alert('Payment successful! Tokens have been added to your account.');
                } else {
                    console.error('Payment completion failed:', result.error);
                    alert('Payment completion failed. Please contact support.');
                }
            },
            onCancel: (paymentId) => {
                console.log('Payment cancelled:', paymentId);
                alert('Payment was cancelled.');
            },
            onError: (error, payment) => {
                console.error('Payment error:', error, payment);
                alert('Payment failed. Please try again.');
            }
        };
        await window.Pi.createPayment(paymentData, callbacks);
    } catch (error) {
        console.error('Payment initiation failed:', error);
        alert('Failed to initiate payment. Please ensure you are using the Pi Browser.');
    }
}