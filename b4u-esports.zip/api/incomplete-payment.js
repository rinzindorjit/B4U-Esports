module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const { paymentId } = req.body;
    if (!paymentId) {
      return res.status(400).json({ success: false, error: 'Payment ID is required' });
    }

    console.log('Handling incomplete payment:', paymentId);
    res.json({ success: true, message: 'Incomplete payment recorded' });
  } catch (error) {
    console.error('Incomplete payment error:', error);
    res.status(500).json({ success: false, error: 'Failed to handle incomplete payment' });
  }
};