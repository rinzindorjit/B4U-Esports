const axios = require('axios');

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const { accessToken } = req.body;
    if (!accessToken) {
      return res.status(400).json({ success: false, error: 'Access token is required' });
    }

    // Note: Pi Network's auth verification endpoint is not publicly documented.
    // For now, assume token is valid. Check Pi Developer Portal for updates.
    res.json({ success: true, message: 'Authentication token received', token: accessToken });
  } catch (error) {
    console.error('Auth verification error:', error);
    res.status(500).json({ success: false, error: 'Server error during auth verification' });
  }
};