const axios = require('axios');

const PI_API_KEY = process.env.PI_API_KEY;
const PI_API_URL = 'https://api.testnet.minepi.com/v2'; // Use 'https://api.minepi.com/v2' for production

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const { paymentId } = req.body;
    if (!paymentId) {
      return res.status(400).json({ success: false, error: 'Payment ID is required' });
    }

    const response = await axios.post(
      `${PI_API_URL}/payments/${paymentId}/approve`,
      {},
      {
        headers: {
          Authorization: `Key ${PI_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    console.log('Payment approved:', response.data);
    res.json({ success: true, message: 'Payment approved' });
  } catch (error) {
    console.error('Payment approval error:', error.response?.data || error.message);
    res.status(500).json({ success: false, error: 'Failed to approve payment' });
  }
};