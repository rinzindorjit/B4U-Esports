const axios = require('axios');

const PI_API_KEY = process.env.PI_API_KEY;
const PI_API_URL = 'https://api.testnet.minepi.com/v2'; // Use 'https://api.minepi.com/v2' for production

module.exports = async (req, res) => {
  if (req.method !== 'POST') {
    return res.status(405).json({ success: false, error: 'Method not allowed' });
  }

  try {
    const { paymentId, txid } = req.body;
    if (!paymentId || !txid) {
      return res.status(400).json({ success: false, error: 'Payment ID and transaction ID are required' });
    }

    const response = await axios.post(
      `${PI_API_URL}/payments/${paymentId}/complete`,
      { txid },
      {
        headers: {
          Authorization: `Key ${PI_API_KEY}`,
          'Content-Type': 'application/json'
        }
      }
    );

    console.log('Payment completed:', response.data);
    res.json({ success: true, message: 'Payment completed successfully' });
  } catch (error) {
    console.error('Payment completion error:', error.response?.data || error.message);
    res.status(500).json({ success: false, error: 'Failed to complete payment' });
  }
};